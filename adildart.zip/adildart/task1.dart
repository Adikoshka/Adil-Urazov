main() {
  DateTime datetime = DateTime.now();
String dateStr = datetime.toString();

print(dateStr);
}