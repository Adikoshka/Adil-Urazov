void main(List<String> args) {
  double base;
  double height;
  double results;
  base = 1;
  height = 1;
  results = (base * height)/2;

  print('area of triangle is $results');
}
