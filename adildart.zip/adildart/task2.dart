void main(List<String> args) {
  double rad;
  double results;
  rad = 12;

  results = 3.14 * rad * rad;

  print('area of circle is $results');
}
